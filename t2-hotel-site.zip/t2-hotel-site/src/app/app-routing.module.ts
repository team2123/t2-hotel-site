import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './components/homepage/homepage.component';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import { OrdersComponent } from './components/orders/orders.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { LogoutComponent } from './components/logout/logout.component';
import { AdminLoginComponent } from './components/admin/admin-login/admin-login.component';
import { UserListComponent } from './components/admin/user-list/user-list.component';
import { UserEditComponent } from './components/admin/user-edit/user-edit.component';
import { ItemAddComponent } from './components/admin/item-add/item-add.component';
import { ItemEditComponent } from './components/admin/item-edit/item-edit.component';
import { ItemListComponent } from './components/admin/item-list/item-list.component';
import { AdminDashboardComponent } from './components/admin/admin-dashboard/admin-dashboard.component';

import { OrderAddressComponent } from './components/order-address/order-address.component';

const routes: Routes = [
  {path:'', component: HomepageComponent},
  {path:'register', component:RegisterComponent},
  {path:'login', component:LoginComponent},
  {path:'order', component: OrdersComponent},
  {path:'dashboard', component:  DashboardComponent},
  {path:'logout', component:  LogoutComponent},
  {path:'admin', component:  AdminLoginComponent},
  {path:'user-list', component:  UserListComponent},
  {path:'user-edit', component:  UserEditComponent},
  {path:'item-add', component:  ItemAddComponent},
  {path:'item-edit', component:  ItemEditComponent},
  {path:'item-list', component: ItemListComponent},
  {path:'admin-dashboard', component: AdminDashboardComponent},
  {path:'order-address',component:OrderAddressComponent},
  {path:'**', component: PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
