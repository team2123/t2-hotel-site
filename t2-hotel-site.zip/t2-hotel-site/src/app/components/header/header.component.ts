import { Component, OnInit } from '@angular/core';
import { CommonserviceService } from "./../../services/commonservice.service";
import { Router } from "@angular/router";
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  loggedin = ''

  constructor(public commonService: CommonserviceService, private router: Router) { }

  ngOnInit(): void {
  }
  logout() {
    this.commonService.setLoginStatus(0)
    this.commonService.setJwtToken('');// Remove the Token from CommonService
    this.router.navigate(['/']);// Redirect to Home Page
  }

}
