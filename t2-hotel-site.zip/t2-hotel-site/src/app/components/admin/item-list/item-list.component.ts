import { Component, OnInit } from '@angular/core';
import { ItemService } from 'src/app/services/item.service';
import { Item } from "./../../../models/item";

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.css']
})
export class ItemListComponent implements OnInit {
  items: Item[] = [];
  total_no_of_records!: number;
  current_page: number = 1;// Pagination setting - Current Page defaulted to First Page
  no_of_records_per_page: number = 5;// Pagination setting - No of records per page set to 5
  message = ''

  constructor(private itemService: ItemService) { }

  ngOnInit() {
    this.getItemList()
  }

  getItemList() {
    this.itemService.getItems().subscribe(
      (result : any) => {
        this.items = result;
        this.total_no_of_records = this.items.length
      },
      (error) => {
        // console.log('error')
        // console.log(error)
        // console.log('error.error.text')
        // console.log(error.error.text)
        // console.log('error.status')
        // console.log(error.status)
        // console.log('error.statusText')
        // console.log(error.statusText)
        //this.message = error.error.text
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error
        }
      }
    );
  }

  delete1Item(item: Item) {
    if(window.confirm(`Are you sure to delete this Item?`)) {
      this.itemService.deleteItem(item._id)
        .subscribe( data => {
          this.items = this.items.filter(u => u !== item);
        })
    }
  }

  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }

}
