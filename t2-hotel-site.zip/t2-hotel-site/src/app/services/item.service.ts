import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonserviceService } from "./commonservice.service";
import { Item } from "./../models/item";

@Injectable({
  providedIn: 'root'
})
export class ItemService {
  api_url:string = "http://localhost:9000/v1/item/"

  jwtToken!: string;
  headers: HttpHeaders = new HttpHeaders;
  constructor(private http: HttpClient, public commonService:CommonserviceService) {}

  getItems() {
    //return this.http.get(this.api_url);
    this.jwtToken = this.commonService.getJwtToken()
    this.headers  = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded', "Authorization": this.jwtToken});
    //console.log('ItemService getItems() : ' + this.jwtToken)
    return this.http.get(this.api_url, {headers: this.headers});
  }

  createItem(formData: FormData) {
    // console.log('3. formData')
    // body.forEach((value, key) => {
    //   console.log(key+" : "+value)
    // });

    //let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    this.jwtToken = this.commonService.getJwtToken()
    this.headers  = new HttpHeaders({"Authorization": this.jwtToken});
    return this.http.post(this.api_url, formData, {headers:this.headers, responseType:'text'});
    // return this.http.post(this.api_url, formData);
  }

  deleteItem(itemid: string) {
    //return this.http.get(this.api_url + '/delete/' + itemid);//Interim
    // return this.http.delete(this.api_url + '/' + itemid);//Actual
    this.jwtToken = this.commonService.getJwtToken()
    this.headers  = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded', "Authorization": this.jwtToken});
    return this.http.delete(this.api_url + itemid, {headers: this.headers});//Actual
  }

  getItemById(itemid: string) {
    // return this.http.get<ItemClass>(this.api_url + '/' + itemid);
    this.jwtToken = this.commonService.getJwtToken()
    this.headers  = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded', "Authorization": this.jwtToken});
    return this.http.get<Item>(this.api_url + itemid, {headers: this.headers});
  }

  updateItem(body: string, itemid: string) {
    // let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    // return this.http.put(this.api_url + '/' + itemid, body, {headers: headers, responseType:'text'});
    this.jwtToken = this.commonService.getJwtToken()
    this.headers  = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded', "Authorization": this.jwtToken});
    return this.http.put(this.api_url + itemid, body, {headers: this.headers, responseType:'text'});
  }
}
