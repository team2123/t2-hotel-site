import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class OrderDeliveryService {
  // api_url:string = "http://localhost:9000/v1/item/"

  
  // headers: HttpHeaders = new HttpHeaders;

  constructor() { }

  // createItem(body: string) {
    // console.log('3. formData')
    // body.forEach((value, key) => {
    //   console.log(key+" : "+value)
    // });

    //let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    
    // let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    // return this.http.post(this.api_url, body, {headers:this.headers, responseType:'text'});
    // return this.http.post(this.api_url, formData);
//   }
}


